import React, { useReducer, createContext, useEffect } from 'react';

// Initial state (empty expenses and default budget if nothing is saved in localStorage)
const initialState = {
    expenses: JSON.parse(localStorage.getItem('expenses')) || [],
    budget: parseFloat(localStorage.getItem('budget')) || 2000, // Default budget of 2000 if not set
};

// Reducer function
const appReducer = (state, action) => {
    switch (action.type) {
        case 'ADD_EXPENSE':
            const updatedExpenses = [...state.expenses, action.payload];
            localStorage.setItem('expenses', JSON.stringify(updatedExpenses)); // Save expenses to localStorage
            return {
                ...state,
                expenses: updatedExpenses,
            };
        case 'DELETE_EXPENSE':
            const filteredExpenses = state.expenses.filter(
                (expense) => expense.id !== action.payload
            );
            localStorage.setItem('expenses', JSON.stringify(filteredExpenses)); // Update localStorage
            return {
                ...state,
                expenses: filteredExpenses,
            };
        case 'EDIT_EXPENSE': // Edit an expense by its id
            const editedExpenses = state.expenses.map((expense) =>
                expense.id === action.payload.id
                    ? { ...expense, ...action.payload }
                    : expense
            );
            localStorage.setItem('expenses', JSON.stringify(editedExpenses)); // Update localStorage with edited expenses
            return {
                ...state,
                expenses: editedExpenses,
            };
        case 'SET_EXPENSES': // Set expenses from localStorage or external source
            return {
                ...state,
                expenses: action.payload,
            };
        case 'SET_BUDGET':
            localStorage.setItem('budget', action.payload); // Save budget to localStorage
            return {
                ...state,
                budget: parseFloat(action.payload),
            };
        default:
            return state;
    }
};

// Create context
export const AppContext = createContext();

// App provider component
export const AppProvider = ({ children }) => {
    const [state, dispatch] = useReducer(appReducer, initialState);

    useEffect(() => {
        // Check localStorage for any saved data when the app loads
        const savedExpenses = JSON.parse(localStorage.getItem('expenses'));
        const savedBudget = localStorage.getItem('budget');

        if (savedExpenses) {
            dispatch({ type: 'SET_EXPENSES', payload: savedExpenses });
        }
        if (savedBudget) {
            dispatch({ type: 'SET_BUDGET', payload: parseFloat(savedBudget) });
        }
    }, []);

    return (
        <AppContext.Provider
            value={{
                expenses: state.expenses,
                budget: state.budget,
                dispatch,
            }}
        >
            {children}
        </AppContext.Provider>
    );
};
